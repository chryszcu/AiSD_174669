namespace BST
{
    public partial class Form1 : Form
    {
        BST tree1 = new BST();

        public Form1()
        {
            InitializeComponent();
        }

        private void ShowNode(NodeT nodeT, TreeNode treeNode)
        {
            if (nodeT == null)
            {
                return;
            }

            treeNode.Text += nodeT.data;

            if (nodeT.lewe != null)
            {
                ShowNode(nodeT.lewe, treeNode.Nodes.Add("Lewy: "));
            }

            if (nodeT.prawe != null)
            {
                ShowNode(nodeT.prawe, treeNode.Nodes.Add("Prawe: "));
            }
        }

        private void Show(BST tree)
        {
            treeView1.Nodes.Clear();
            ShowNode(tree.root, treeView1.Nodes.Add("Korzen: "));
            treeView1.ExpandAll();
        }

        private void PreOrder(NodeT nodeT)
        {
            if (nodeT == null)
            {
                return;
            }

            textBox3.Text += nodeT.data.ToString();
            textBox3.Text += " ";
            PreOrder(nodeT.lewe);
            PreOrder(nodeT.prawe);
        }

        private void InOrder(NodeT nodeT)
        {
            if (nodeT == null)
            {
                return;
            }

            InOrder(nodeT.lewe);
            textBox4.Text += nodeT.data.ToString();
            textBox4.Text += " ";
            InOrder(nodeT.prawe);
        }

        private void PostOrder(NodeT nodeT)
        {
            if (nodeT == null)
            {
                return;
            }
            PostOrder(nodeT.lewe);
            PostOrder(nodeT.prawe);
            textBox5.Text += nodeT.data.ToString();
            textBox5.Text += " ";
        }

        public NodeT Znajdz(NodeT nodeT, int liczba)
        {
            if (nodeT == null || nodeT.data == liczba)
            {
                return nodeT;
            }

            if (liczba < nodeT.data)
            {
                return Znajdz(nodeT.lewe, liczba);
            }
            else
            {
                return Znajdz(nodeT.prawe, liczba);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox3.Clear();
            PreOrder(tree1.root);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var liczba = int.Parse(textBox1.Text);
            tree1.Add(liczba);
            textBox5.Clear();
            treeView1.Nodes.Clear();
            Show(tree1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox4.Clear();
            InOrder(tree1.root);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox5.Clear();
            PostOrder(tree1.root);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var liczba = int.Parse(textBox2.Text);
            NodeT nodeT = Znajdz(tree1.root, liczba);
            tree1.UsunElement(nodeT);
            textBox2.Clear();
            treeView1.Nodes.Clear();
            Show(tree1);   
        }
    }
}
