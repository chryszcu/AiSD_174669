﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BST
{
    public class BST
    {
        public NodeT root;

        public BST()
        {
            root = null;
        }

        public NodeT ZnajdzRodzic(NodeT dziecko)
        {
            var zm = this.root;
            while(true)
            {
                if(zm.data > dziecko.data)
                {
                    if(zm.lewe == null)
                    {
                        return zm;
                    }
                    else
                    {
                        zm = zm.lewe;
                    }
                }
                else
                {
                    if(zm.prawe == null)
                    { 
                        return zm;
                    }
                    else
                    {
                        zm = zm.prawe; 
                    }
                }
            }
        }

        public void Add(int liczba)
        {
            var dziecko = new NodeT(liczba);
            if(this.root == null)
            {
                this.root = dziecko;
                return;
            }

            var rodzic = this.ZnajdzRodzic(dziecko);
            dziecko.rodzic = rodzic;
            if(rodzic.data > dziecko.data)
            {
                rodzic.lewe = dziecko;
            }
            else
            {
                rodzic.prawe = dziecko;
            }
        }

        public int IloscDzieci(NodeT nodeT)
        {
            int wynik = 0;
            if (nodeT.lewe != null) wynik++;
            if (nodeT.prawe != null) wynik++;
            return wynik;
        }

        public void UsunElement(NodeT nodeT)
        {
            if(nodeT == null)
            {
                return;
            }

            int dzieci = IloscDzieci(nodeT);

            if(dzieci == 0)
            {
                if (nodeT == root)
                {
                    root = null;
                }
                else
                { 
                    UsunElement0(nodeT);
                }
            }

            else if (dzieci == 1)
            {
                NodeT dziecko = UsunElement1(nodeT);
                Zamien(nodeT, dziecko);
            }

            else if (dzieci == 2)
            {
                var nastepny = Min(nodeT.prawe);
                nodeT.data = nastepny.data;
                UsunElement(nastepny);
            }
            nodeT.rodzic = null;
            nodeT.lewe = null;
            nodeT.prawe = null;
        }

        public void UsunElement0(NodeT nodeT)
        {
            if (nodeT.rodzic == null)
            {
                this.root = null;
            }
            else if (nodeT.rodzic.lewe == nodeT)
            {
                nodeT.rodzic.lewe = null;
            }
            else if (nodeT.rodzic.prawe == nodeT)
            {
                nodeT.rodzic.prawe = null;
            }
            nodeT.rodzic = null;
        }

        public NodeT UsunElement1(NodeT nodeT)
        {
            NodeT dziecko = null;
            if (nodeT.lewe != null)
            {
                dziecko = nodeT.lewe;
                this.UsunElement0(dziecko);
            }
            else if (nodeT.prawe != null)
            {
                dziecko = nodeT.prawe;
                this.UsunElement0(dziecko);
            }
            return dziecko;
        }

        public void Zamien(NodeT nodeT, NodeT dziecko)
        {
            if (nodeT.rodzic == null)
            {
                this.root = dziecko;
            }
            else if (nodeT.rodzic.lewe == nodeT)
            {
                nodeT.rodzic.lewe = dziecko;
            }
            else
            {
                nodeT.rodzic.prawe = dziecko;
            }

            if (dziecko != null)
            {
                dziecko.rodzic = nodeT.rodzic;
            }
        }

        public NodeT Min(NodeT nodeT)
        {
            var zm = nodeT;
            while (zm.lewe != null)
            {
                zm = zm.lewe;
            }
            return zm;
        }
    }
}
