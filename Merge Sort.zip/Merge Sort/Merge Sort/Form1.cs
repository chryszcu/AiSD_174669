namespace Merge_Sort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void MergeSort(int[] tab, int left, int right)
        {
            if (left >= right)
            {
                return;
            }

            int mid = (left + right) / 2;

            MergeSort(tab, left, mid);
            MergeSort(tab, mid + 1, right);
            Merge(tab, left, mid, right);

        }

        private void Merge(int[] tab, int left, int mid, int right)
        {
            int[] leftTab = new int[mid - left + 1];
            int[] rightTab = new int[right - mid];

            Array.Copy(tab, left, leftTab, 0, leftTab.Length);
            Array.Copy(tab, mid + 1, rightTab, 0, rightTab.Length);

            int i = 0, j = 0, k = left;
            while (i < leftTab.Length && j < rightTab.Length)
            {
                if (leftTab[i] <= rightTab[j])
                {
                    tab[k] = leftTab[i];
                    i++;
                }
                else
                {
                    tab[k] = rightTab[j];
                    j++;
                }
                k++;
            }

            while (i < leftTab.Length)
            {
                tab[k] = leftTab[i];
                i++;
                k++;
            }

            while (j < rightTab.Length)
            {
                tab[k] = rightTab[j];
                j++;
                k++;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] tab = { 5, 3, 8, 1, 4, 2 };

            listBox1.Items.Clear();
            for(int i = 0; i < tab.Length; i++)
            {
                listBox1.Items.Add(tab[i]);
            }

            MergeSort(tab, 0, tab.Length - 1);

            listBox2.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox2.Items.Add(tab[i]);
            }

        }
    }
}
