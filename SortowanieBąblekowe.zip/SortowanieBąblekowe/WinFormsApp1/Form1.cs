using System;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void SortowanieBabelkowe(int[] tab)
        {
            int n = tab.Length;
            for (int i = 0; i < n - 1; i++)
            {
                for (int j = 0; j < n - i - 1; j++)
                {
                    if (tab[j] > tab[j + 1])
                    {
                        int temp = tab[j];
                        tab[j] = tab[j + 1];
                        tab[j + 1] = temp;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] tab = { 5, 4, 3, 2, 1, 9, 7, 8, 6 };
            listBox2.Items.Clear();
            foreach (var num in tab)
            {
                listBox2.Items.Add(num);
            }

            SortowanieBabelkowe(tab);

            listBox1.Items.Clear();
            foreach (var num in tab)
            {
                listBox1.Items.Add(num);
            }
        }
    }
}
