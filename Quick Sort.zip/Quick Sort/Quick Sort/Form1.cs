using System.Collections.Concurrent;

namespace Quick_Sort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void QuickSort(int[] tab, int low, int high)
        {
            if (low < high)
            {
                int pi = Partition(tab, low, high);
                QuickSort(tab, low, pi - 1);
                QuickSort(tab, pi + 1, high);
            }
        }

        private int Partition(int[] tab, int low, int high)
        {
            int pivot = tab[high];
            int i = (low - 1);

            for (int j = low; j < high; j++)
            {
                if (tab[j] <= pivot)
                {
                    i++;
                    Swap(tab, i, j);
                }
            }

            Swap(tab, i + 1, high);
            return i + 1;
        }

        private void Swap(int[] tab, int i, int j)
        {
            int temp = tab[i];
            tab[i] = tab[j];
            tab[j] = temp;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] tab = { 5, 3, 8, 1, 4, 2, 7, 6 };
            listBox1.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox1.Items.Add(tab[i]);
            }

            QuickSort(tab, 0, tab.Length - 1);

            listBox2.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox2.Items.Add(tab[i]);
            }
        }
    }
}
