﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listy
{
    internal class Node
    {
        public Node Next { get; set; }
        public Node Prev { get; set; }
        public int Data { get; set; }
        public Node(int data)
        {
            Data = data;
            Next = null;
            Prev = null;
        }
    }
}
