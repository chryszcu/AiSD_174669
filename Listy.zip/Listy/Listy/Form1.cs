using System.Text;

namespace Listy
{
    public partial class Form1 : Form
    {
        private Listy listy;
        public Form1()
        {
            InitializeComponent();
            listy = new Listy();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int value))
            {
                Node node = new Node(value);
                listy.DodajPierwszy(node);
                textBox1.Clear();
            }
            textBox2.Text = GetListContent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int value))
            {
                Node node = new Node(value);
                listy.DodajOstatni(node);
                textBox1.Clear();
            }
            textBox2.Text = GetListContent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listy.UsunPierwszy();
            textBox2.Text = GetListContent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            listy.UsubOstani();
            textBox2.Text = GetListContent();
        }

        private string GetListContent()
        {
            var content = new StringBuilder();
            Node current = listy.glowa;
            while (current != null)
            {
                content.Append("[ ");
                content.Append(DisplayNodeData(current));
                content.Append(" ] -> ");
                current = current.Next;
            }
            content.Append("null");
            return content.ToString();
        }

        private string DisplayNodeData(Node node)
        {
            return node.Data.ToString();
        }
    }
}
