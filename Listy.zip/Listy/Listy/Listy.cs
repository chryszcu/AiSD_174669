﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Listy
{
    internal class Listy
    {
        public Node glowa { get; private set; }
        private Node ogon;

        public void DodajPierwszy(Node node)
        {
            if(glowa == null)
            {
                glowa = node;
                ogon = node;
            }
            else
            {
                node.Next = glowa;
                glowa.Prev = node;
                glowa = node;
            }
        }

        public void DodajOstatni(Node node)
        {
            if (ogon == null)
            {
                glowa = node;
                ogon = node;
            }
            else
            {
                ogon.Next = node;
                node.Prev = ogon;
                ogon = node;
            }
        }

        public void UsunPierwszy()
        {
            if(glowa == null)
            {
                return;
            }

            if(glowa == ogon)
            {
                glowa = null;
                ogon = null;
            }
            else
            {
                glowa = glowa.Next;
                glowa.Prev = null;
            }
        }

        public void UsubOstani()
        {
            if(ogon == null)
            {
                return;
            }

            if(glowa == ogon)
            {
                glowa = null;
                ogon = null;
            }
            else
            {
                ogon = ogon.Prev;
                ogon.Next = null;
            }
        }
    }
}
