﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kodowanie_Huffmana
{
    public class NodeG
    {
        public NodeG Left { get; set; }
        public NodeG Right { get; set; }
        public NodeG Rodzic { get; set; }
        public int Data { get; set; }
    }
}
