﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kodowanie_Huffmana
{
    public class NodeGS : NodeG
    {
        public char Symbol { get; set; }
    }
}
