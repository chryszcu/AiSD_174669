namespace Counting_Sort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CountingSort(int[] tab)
        {
            int max = FindMax(tab);
            int[] count = new int[max + 1];

            foreach (var num in tab)
            {
                count[num]++;
            }

            int index = 0;
            for (int i = 0; i < count.Length; i++)
            {
                while (count[i] > 0)
                {
                    tab[index] = i;
                    index++;
                    count[i]--;
                }
            }
        }

        private int FindMax(int[] tab)
        {
            int max = tab[0];
            foreach (var num in tab)
            {
                if (num > max)
                {
                    max = num;
                }
            }
            return max;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            int[] tab = { 5, 3, 8, 1, 4, 2, 1, 3, 7, 6 };

            listBox1.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox1.Items.Add(tab[i]);
            }

            CountingSort(tab);

            listBox2.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox2.Items.Add(tab[i]);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
