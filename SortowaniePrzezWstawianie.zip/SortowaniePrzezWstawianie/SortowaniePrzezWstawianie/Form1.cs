namespace SortowaniePrzezWstawianie
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void SortowaniePrzezWstawianie(int[] tab)
        {
            int n = tab.Length;
            for (int i = 1; i < n; i++)
            {
                int temp = tab[i];
                int j = i - 1;

                while (j >= 0 && tab[j] > temp)
                {
                    tab[j + 1] = tab[j];
                    j--;
                }
                tab[j + 1] = temp;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] tab = { 5, 3, 8, 1, 4, 2 };

            listBox1.Items.Clear();          
            for(int i = 0; i < tab.Length; i++)
            {
                listBox1.Items.Add(tab[i]);
            }

            SortowaniePrzezWstawianie(tab);

            listBox2.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox2.Items.Add(tab[i]);
            }
        }
    }
}
