using System;
using System.Windows.Forms;

namespace Sortowanie
{
    public partial class Form1 : Form
    {
        private int[] tab = { 8, 5, 2, 0, 7, 1 };

        public Form1()
        {
            InitializeComponent();
            Wypisz(tab, listBox1);
        }

        private void Wypisz(int[] tab, ListBox listBox)
        {
            listBox.Items.Clear();
            for (int i = 0; i < tab.Length; i++)
            {
                listBox.Items.Add(tab[i]);
            }
        }

        private void Sortowanie(int[] tab)
        {
            int tmp;
            for (int i = 0; i < tab.Length - 1; i++)
            {
                for (int j = 0; j < tab.Length - 1 - i; j++)
                {
                    if (tab[j] > tab[j + 1])
                    {
                        tmp = tab[j];
                        tab[j] = tab[j + 1];
                        tab[j + 1] = tmp;
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Sortowanie(tab);
            Wypisz(tab, listBox2);
        }
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
